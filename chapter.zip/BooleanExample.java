package chapter;

public class BooleanExample {

	public static void main(String[] args) {
			
		boolean stop = false;
		
		if(stop) {
			System.out.println("�����մϴ�.");
		}
		else {
			System.out.println("�����մϴ�.");
		}
		
		
	}

}
