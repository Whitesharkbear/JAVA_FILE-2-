package chapter;

public class CarExample {

	public static void main(String[] args) {

		Car myCar = new Car("����",3000);

	}

}
