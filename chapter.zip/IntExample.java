package chapter;

public class IntExample {

	public static void main(String[] args) {

		int var1 = 10;
		int var2 = 012;
		int var3 = 0xA;
		
		System.out.println(var1);
		System.out.println(var2);
		System.out.println(var3);
		
		int var4 = 100;
		int var5 = 0144;
		int var6 = 0x64;
		
		System.out.println(var4);
		System.out.println(var5);
		System.out.println(var6);
		
		
	}

}
