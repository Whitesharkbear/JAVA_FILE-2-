package chapter;

public class Korean {

	String nation = "���ѹα�";
	String name;
	String ssn;
	
	public Korean(String n, String s) {
		name = n;
		ssn = s;
	}
	
	
}
