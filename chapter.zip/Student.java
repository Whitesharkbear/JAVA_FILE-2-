package chapter;

public class Student {

}
